#!/usr/bin/python

import re,sys
from collections import defaultdict
from collections import OrderedDict
from operator import itemgetter
dictionary_result = defaultdict(lambda: defaultdict(lambda:float(1)))

def forward(x,y,dictionary_tmp_f):
    
    if x==0 and y == 0:
        dictionary_tmp_f[(x,y)] = 1.
        return dictionary_tmp_f[(x,y)]
    if (x,y) in dictionary_tmp_f:
        return dictionary_tmp_f[(x,y)]

    j_start = x-1
    #if the x is the first one it need to start at first 
    if j_start != 0:
        j_end = y
    else:
        j_end = x 
    
    for j_index in xrange(j_start,j_end):
        #get the j string
        if y-j_index>3:
            continue
        j_string="" 
        for i in xrange(j_index,y):
            j_string += jpron[i] + ' '
        j_string = j_string[:-1]
    
        dictionary_tmp_f[(x,y)] += forward(x-1,j_index,dictionary_tmp_f)*dictionary_result[epron[x-1]][j_string]
    return dictionary_tmp_f[(x,y)]

def backward(x,y,dictionary_tmp_b):

    if x == len(epron) and y==len(jpron):
        dictionary_tmp_b[(x,y)]=1.
        return dictionary_tmp_b[(x,y)]
    if x == len(epron) or y== len(jpron):
        return 0
    if (x,y) in dictionary_tmp_b:
        return dictionary_tmp_b[(x,y)]

    j_start = y
    if x+1 == len(epron):
        j_start = len(jpron)-1
    j_end   = x+len(jpron)-len(epron)+1

    for j_index in xrange(j_start,j_end):
        if j_index-y>2:
            continue
        j_string="" 
        for i in xrange(y,j_index+1):
            j_string += jpron[i] + ' '
        j_string = j_string[:-1]

        dictionary_tmp_b[(x,y)] += backward(x+1,j_index+1,dictionary_tmp_b)*dictionary_result[epron[x]][j_string]
    return dictionary_tmp_b[(x,y)]

def normalize(dictionary_result_new):
    for (a,b) in dictionary_tmp_f:
        if (a,b) is (3,4):
            continue
        for (c,d) in dictionary_tmp_f:
            if c != a+1 or  b==d: continue
            e_w = epron[a]
            j_string=""
            for j in xrange(b,d):
                j_string += jpron[j] + ' '
            j_string = j_string[:-1]
            dictionary_result_new[e_w][j_string] += dictionary_tmp_f[(a,b)]*dictionary_tmp_b[(c,d)]*dictionary_result[e_w][j_string]/p_x
    return dictionary_result_new

def _normal(dictionary_tmp):
    for epron in dictionary_tmp:
        probs = 0.
        for jpron in dictionary_tmp[epron]:
            probs += dictionary_tmp[epron][jpron]

        for jpron in dictionary_tmp[epron]:
            dictionary_tmp[epron][jpron] = dictionary_tmp[epron][jpron]/probs



times = int(sys.argv[1])
list = sys.stdin.readlines()
gap = int(sys.argv[2])
for _time in xrange(times):

    _line=0
    dictionary_result_tmp = defaultdict(lambda: defaultdict( lambda: defaultdict(lambda:float())))
    p = defaultdict(lambda:float())
    total_p=1.

    while _line<len(list)-1:
        #get the E-K pair 
        epron = list[_line].split()
        jpron = list[_line+1].split()
        if epron[0] == 'PAUSE':
            break
        _line += gap

        dictionary_tmp_f = defaultdict(lambda:float())
        dictionary_tmp_b = defaultdict(lambda:float())

        forward(len(epron),len(jpron),dictionary_tmp_f)
        backward(0,0,dictionary_tmp_b)

        p_x = dictionary_tmp_b[(0,0)]
        p[_line] = p_x
        
        normalize(dictionary_result_tmp[_line])


    dictionary_tmp = defaultdict(lambda: defaultdict( lambda: float()))
    for i in dictionary_result_tmp:
        total_p = total_p * p[i]

        for epron in dictionary_result_tmp[i]:

            for jpron in dictionary_result_tmp[i][epron]:
                dictionary_tmp[epron][jpron] += dictionary_result_tmp[i][epron][jpron]
    _normal(dictionary_tmp)

    for e_w in dictionary_tmp:
        for j_string in dictionary_tmp[e_w]:
            dictionary_result[e_w][j_string] = dictionary_tmp[e_w][j_string]

    print 'iteration '+str(_time)+' ----- corpus prob = ' + str(total_p)
    count_nozeros = 0
    for e_w in dictionary_result:
        d = OrderedDict(sorted(dictionary_result[e_w].items(), key=lambda x:x[1],reverse=True))
        string = e_w+'|->'+'\t'
        for j_w in d:
            if d[j_w] <= 0.01:
                continue
            string = string + j_w + ': '+str(d[j_w])+' '
            count_nozeros += 1
        print string
    print 'nonzeros = ' + str(count_nozeros)
        
